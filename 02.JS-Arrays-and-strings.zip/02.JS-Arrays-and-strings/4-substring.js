function solve(text, start, count) {
    let result = text.substring(start, start + count);

    console.log(result);
}

solve('ASentence', 1, 8);
