console.log(globalThis === global);
console.log(globalThis === this);
console.log(module.exports === this);

