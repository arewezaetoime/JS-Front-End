function showText() {
    const moreButton = document.getElementById('more');
    const hiddenText = document.getElementById('text');

    moreButton.style.display = 'none';
    hiddenText.style.display = 'inline';
}
