function solve(first, second, third) {
    const largestNumber = Math.max(first, second, third);

    console.log(`The largest number is ${largestNumber}`);
}

solve(5, -3, 16);
