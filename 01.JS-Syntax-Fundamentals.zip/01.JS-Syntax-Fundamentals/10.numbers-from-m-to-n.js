function solve(m, n) {
    for (let i = m; i >= n; i--) {
        console.log(i);
    }
}

solve(4, 1);

