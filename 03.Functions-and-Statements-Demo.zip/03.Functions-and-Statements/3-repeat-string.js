function solve(text, count) {
    return text.repeat(count);
}

console.log(solve("abc", 3));
