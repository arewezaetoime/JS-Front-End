// Arrow function statement body
const sum = (a, b) => {
    const result = a + b;

    return result;
}

// Arrow function expression body
const sum2 = (a, b) => a + b;

// Expression body arrow functino with single parameter
const double = num => num * 2;


